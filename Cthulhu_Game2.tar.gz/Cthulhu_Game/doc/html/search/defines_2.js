var searchData=
[
  ['screenheight',['ScreenHeight',['../main_8cc.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;main.cc'],['../procedures_8h.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;procedures.h'],['../structures_8h.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;structures.h']]],
  ['screenwidth',['ScreenWidth',['../main_8cc.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;main.cc'],['../procedures_8h.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;procedures.h'],['../structures_8h.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;structures.h']]]
];
