var searchData=
[
  ['carica_5ffile',['carica_file',['../main_8cc.html#a10c88546e6a4791253699dc20792c55c',1,'carica_file(int &amp;bestscore):&#160;main.cc'],['../procedures_8h.html#a9afc6ea44ca6a5aaa2f0413af72ca968',1,'carica_file(int &amp;):&#160;main.cc']]],
  ['ch',['ch',['../structcthulhu__t.html#ae0365ebe438a718b77348c8fcdb8f2b3',1,'cthulhu_t']]],
  ['collisions',['collisions',['../cthulhu_8cc.html#aa1413403aa9603acdf938804b2574b3e',1,'collisions(int &amp;cont, monster_t mon[], cthulhu_t &amp;c, int &amp;score):&#160;cthulhu.cc'],['../procedures_8h.html#adb35b9b3079551e266f989343f0de1ee',1,'collisions(int &amp;, monster_t mon[], cthulhu_t &amp;c, int &amp;):&#160;cthulhu.cc']]],
  ['crea_5fmoneta',['crea_moneta',['../cthulhu_8cc.html#a2e487e6a8f124b19bd2be2fe7e8edbaf',1,'crea_moneta(moneta_t &amp;m, cthulhu_t &amp;c, int &amp;score):&#160;cthulhu.cc'],['../procedures_8h.html#a1478e3deed922583ce6d447e3e7f52df',1,'crea_moneta(moneta_t &amp;m, cthulhu_t &amp;c, int &amp;):&#160;cthulhu.cc']]],
  ['crea_5fmostro',['crea_mostro',['../cthulhu_8cc.html#a3d9c45717a426dad07e51b5914ed0364',1,'crea_mostro(monster_t mon[], int &amp;i):&#160;cthulhu.cc'],['../procedures_8h.html#a15808ddd629deffc589e7791866c75b6',1,'crea_mostro(monster_t mon[], int &amp;):&#160;cthulhu.cc']]],
  ['cthulhu_2ecc',['cthulhu.cc',['../cthulhu_8cc.html',1,'']]],
  ['cthulhu_5fbmp',['cthulhu_bmp',['../structcthulhu__t.html#ae64785d53bb26aad620808795e94bd3f',1,'cthulhu_t']]],
  ['cthulhu_5ft',['cthulhu_t',['../structcthulhu__t.html',1,'']]],
  ['cw',['cw',['../structcthulhu__t.html#aa6ce80f98bcab297b2f3607748641cff',1,'cthulhu_t']]],
  ['cthulhu_5fgame',['cthulhu_game',['../index.html',1,'']]]
];
