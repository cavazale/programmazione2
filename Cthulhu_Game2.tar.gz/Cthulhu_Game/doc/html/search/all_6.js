var searchData=
[
  ['initialize',['initialize',['../cthulhu_8cc.html#a9cd273170dea812a748ae3d9081d682e',1,'initialize(moneta_t &amp;m, cthulhu_t &amp;c, monster_t mon[]):&#160;cthulhu.cc'],['../procedures_8h.html#a9cd273170dea812a748ae3d9081d682e',1,'initialize(moneta_t &amp;m, cthulhu_t &amp;c, monster_t mon[]):&#160;cthulhu.cc']]]
];
