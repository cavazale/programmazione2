var searchData=
[
  ['game',['game',['../cthulhu_8cc.html#a40244e38a0230660613f244bdb496161',1,'game(cthulhu_t &amp;c):&#160;cthulhu.cc'],['../procedures_8h.html#a40244e38a0230660613f244bdb496161',1,'game(cthulhu_t &amp;c):&#160;cthulhu.cc']]],
  ['game_5fover',['game_over',['../cthulhu_8cc.html#a8a495124d71af228d1290417701a02a6',1,'game_over(int &amp;score):&#160;cthulhu.cc'],['../procedures_8h.html#ace798f3f5b84548c16ca88d7c6ca4fe0',1,'game_over(int &amp;):&#160;cthulhu.cc']]]
];
