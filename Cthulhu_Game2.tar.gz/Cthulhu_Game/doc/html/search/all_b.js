var searchData=
[
  ['salva_5ffile',['salva_file',['../cthulhu_8cc.html#ae5d1c1f61003ad310381abc84145277e',1,'salva_file(const int &amp;n):&#160;cthulhu.cc'],['../procedures_8h.html#a2398f78ca25f2b0b6c3ed6908d455dfa',1,'salva_file(const int &amp;):&#160;cthulhu.cc']]],
  ['screenheight',['ScreenHeight',['../main_8cc.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;main.cc'],['../procedures_8h.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;procedures.h'],['../structures_8h.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;structures.h']]],
  ['screenwidth',['ScreenWidth',['../main_8cc.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;main.cc'],['../procedures_8h.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;procedures.h'],['../structures_8h.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;structures.h']]],
  ['speed',['speed',['../structcthulhu__t.html#a7ead571f9eecb9f957cb74b45d87bbed',1,'cthulhu_t']]],
  ['speed_5fmonster',['speed_monster',['../structmonster__t.html#af64e19c967c2f5ea303610d2ada0a1e7',1,'monster_t']]],
  ['structures_2eh',['structures.h',['../structures_8h.html',1,'']]]
];
