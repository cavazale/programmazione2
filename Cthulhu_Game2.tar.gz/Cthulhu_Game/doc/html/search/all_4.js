var searchData=
[
  ['fps',['FPS',['../cthulhu_8cc.html#ac92ca5ab87034a348decad7ee8d4bd1b',1,'FPS():&#160;cthulhu.cc'],['../procedures_8h.html#ac92ca5ab87034a348decad7ee8d4bd1b',1,'FPS():&#160;procedures.h']]],
  ['framefps',['frameFPS',['../cthulhu_8cc.html#af271794b1fabeac26ef6e0f9a3a4e674',1,'cthulhu.cc']]]
];
