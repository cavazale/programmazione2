var searchData=
[
  ['dir_5fsu',['dir_su',['../structcthulhu__t.html#aa2da444830f70eeb84ee6646b4371e14',1,'cthulhu_t']]],
  ['distruggi',['distruggi',['../cthulhu_8cc.html#ac62c8ae52d018c626c43dcb247c88a61',1,'distruggi(bool &amp;fine, ALLEGRO_EVENT_QUEUE *event_queue1, ALLEGRO_TIMER *timer):&#160;cthulhu.cc'],['../procedures_8h.html#a984481a0d928b89639938a33ef7a9f31',1,'distruggi(bool, ALLEGRO_EVENT_QUEUE, ALLEGRO_TIMER):&#160;procedures.h']]],
  ['draw',['draw',['../main_8cc.html#a5d4a6684b846ae50d6f0f141df41058c',1,'draw(ALLEGRO_FONT *font, ALLEGRO_FONT *font2, ALLEGRO_BITMAP *cthulhu, int x, int y):&#160;main.cc'],['../procedures_8h.html#a1487f17c9a2d11f6ebc104f1efcc1a13',1,'draw(ALLEGRO_FONT, ALLEGRO_FONT, ALLEGRO_BITMAP, int, int):&#160;procedures.h']]],
  ['draw2',['draw2',['../cthulhu_8cc.html#a7aebf4704e862e34c6a98694f283ec3a',1,'draw2(moneta_t &amp;m, cthulhu_t &amp;c, monster_t mon[], ALLEGRO_BITMAP *monster, ALLEGRO_BITMAP *sfondo, ALLEGRO_FONT *font_score, int score):&#160;cthulhu.cc'],['../procedures_8h.html#ab1825a490ea896091e0f093c7d97ab99',1,'draw2(moneta_t &amp;m, cthulhu_t &amp;c, monster_t mon[], ALLEGRO_BITMAP, ALLEGRO_BITMAP, ALLEGRO_FONT, int):&#160;procedures.h']]]
];
