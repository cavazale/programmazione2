var searchData=
[
  ['trova_5fmassimo',['trova_massimo',['../cthulhu_8cc.html#aaa4e2f9209170cb16a1e53b077a681a3',1,'trova_massimo(int &amp;score):&#160;cthulhu.cc'],['../procedures_8h.html#ab7e0f1a653ed6cee1143078e8e214e35',1,'trova_massimo(int &amp;):&#160;cthulhu.cc']]]
];
