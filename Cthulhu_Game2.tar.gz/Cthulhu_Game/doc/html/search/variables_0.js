var searchData=
[
  ['active',['active',['../structmonster__t.html#ac53735eac84003cc3e52e837272e152e',1,'monster_t']]]
];
