/**
 * @file 
 * funzioni per implementare il gioco
 */

#include <iostream>
#include <stdio.h>
#include <ctime>
#include <fstream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>
#include "structures.h"
#include "procedures.h"

using namespace std;

#define Min 1.5              /**< altezza minima a cui può arrivare il player prima di perdere la partita */
#define Max ScreenHeight-70  /**< altezza massima a cui può arrivare il player prima di perdre la partita */
#define FPS 60               /**< variabile utilizzata per settare la velocità del timer */
#define frameFPS 60
#define MonetaSu 150                    /**< altezza della moneta quando si trova nella parte alta del display */
#define MonetaGiu ScreenHeight-150      /**< altezza della moneta quando si trova nella parte bassa del display */

const int NUM_MAX = 5;      /**< numero massimo di mostri che possono apparire contemporaneamente nel display */

int bestscore;              /**< variabile di tipo int che memorizza il miglior punteggio */

/**
 *  Funzione ::salva_file
 */
bool salva_file(const int &n){
  ofstream f("bestscore.txt");
  if(!f)
    return false;
  f<<n;
  return f;
}
/**
 *  Funzione ::trova_massimo
 */
void trova_massimo(int &score){
  if(score >= bestscore){
    bestscore = score;
    salva_file(bestscore);
  }
}
/**
 *  Funzione ::crea_mostro
 */
void crea_mostro(monster_t mon[], int &i){
  srand(time(0));
  mon[i].active = true;
  mon[i].x = ScreenWidth;
  mon[i].y = (rand()%(ScreenHeight-300))+150;
  mon[i].speed_monster = (rand()%7)+6;
}

/**
 *  Funzione ::collisions
 */
bool collisions(int &cont, monster_t mon[], cthulhu_t &c, int &score){
  int i;
  for(i=0; i<NUM_MAX; i++){
    if (cont >= 45 && mon[i].active == false){
      crea_mostro(mon, i);
      cont = 0;
    }
    if (mon[i].active == true){
      mon[i].x -= mon[i].speed_monster;
      if (mon[i].x <= 0){
	mon[i].active = false;
      }
      if (c.x <= mon[i].x && c.x + c.cw >= mon[i].x){
	if ((mon[i].y >= c.y - mon[i].mh) && (mon[i].y + mon[i].mh <= c.y + c.ch + mon[i].mh)){
	  game_over(score);
	  return false;
	}
      }
    }
  }
  cont++;
  return true;
}
/**
 *  Funzione ::crea_moneta
 */
void crea_moneta(moneta_t &m, cthulhu_t &c, int &score){
  if (m.UP == true){
    m.my = MonetaSu;
    if (c.y >= m.my && c.y <= m.my+m.mh){
      m.UP = false;
      score+=10;
      trova_massimo(score);
    }
  }else{
    m.my = MonetaGiu;
    if (c.y + c.ch >= m.my && c.y + c.ch <= m.my+m.mh){
      m.UP = true;
      score+=10;
      trova_massimo(score);
    }
  }
}
/**
 *  Funzione ::game_over
 */
void game_over(int &score){
  carica_file(bestscore);
  
  ALLEGRO_EVENT_QUEUE *event_queue2 = al_create_event_queue();
  ALLEGRO_FONT *font_game_over = al_load_ttf_font ("media/horror.ttf", 80, 0);
  ALLEGRO_FONT *font_game_over2 = al_load_ttf_font ("media/horror.ttf", 50, 0);
  al_clear_to_color(al_map_rgb(0, 50, 40));
  al_draw_text(font_game_over, al_map_rgb(0, 70, 60), ScreenWidth/2, (ScreenHeight/6), ALLEGRO_ALIGN_CENTRE, "Game Over");
  al_draw_textf(font_game_over2, al_map_rgb(0, 70, 70), ScreenWidth/2, (ScreenHeight/3), ALLEGRO_ALIGN_CENTRE, "SCORE: %d", score);
  al_draw_textf(font_game_over2, al_map_rgb(0, 70, 70), ScreenWidth/2, (ScreenHeight/2.5), ALLEGRO_ALIGN_CENTRE, "BESTSCORE: %d", bestscore);
  al_draw_text(font_game_over2, al_map_rgb(0,70,60), ScreenWidth/2, (ScreenHeight/1.7), ALLEGRO_ALIGN_CENTRE, "Press Esc to main menu");
  al_flip_display();
  al_register_event_source(event_queue2, al_get_keyboard_event_source());
  while(true){
    ALLEGRO_EVENT events;
    al_wait_for_event(event_queue2, &events);
    if (events.type == ALLEGRO_EVENT_KEY_DOWN){
      if (events.keyboard.keycode == ALLEGRO_KEY_ESCAPE){
	al_destroy_event_queue(event_queue2);
        return;
      }
    }
  }
}
/**
 *  Funzione ::draw2
 */
void draw2(moneta_t &m, cthulhu_t &c, monster_t mon[], ALLEGRO_BITMAP *monster, ALLEGRO_BITMAP *sfondo, ALLEGRO_FONT *font_score, int score){
  al_clear_to_color(al_map_rgb(0,0,0));
  al_convert_mask_to_alpha(m.monete, al_map_rgb(255, 255,255));
  al_convert_mask_to_alpha(c.cthulhu_bmp, al_map_rgb(255, 255,255));
  al_draw_bitmap(sfondo, 0, 0, 0);
  al_draw_bitmap(c.cthulhu_bmp, c.x, c.y, 0);
  al_draw_bitmap (m.monete, m.mx, m.my, 0);
  
  for(int i=0; i<NUM_MAX; i++){
    if(mon[i].active == true){
      al_convert_mask_to_alpha(monster, al_map_rgb(255, 255,255));
      al_draw_bitmap(monster, mon[i].x, mon[i].y, 0);
    }
  }
  al_draw_textf(font_score, al_map_rgb(0, 70, 60), 550, 30, ALLEGRO_ALIGN_CENTRE, "SCORE: %d", score);
  al_flip_display();
  
}
/**
 *  Funzione ::initialize
 */
void initialize(moneta_t &m, cthulhu_t &c, monster_t mon[]){
  m.UP = true;
  m.my = MonetaSu;
  c.dir_su = true;
  c.y = ScreenHeight/2;
  for(int i=0; i<NUM_MAX; i++){
    mon[i].active = false;
  }
}
/**
 *  Funzione ::distruggi
 */
void distruggi(bool &fine, ALLEGRO_EVENT_QUEUE *event_queue1, ALLEGRO_TIMER *timer){
  al_destroy_event_queue(event_queue1);
  al_destroy_timer(timer);
  fine = true;
  return;
}
/**
 *  Funzione ::game
 */
void game(cthulhu_t &c){
  
  ALLEGRO_BITMAP *monster = al_load_bitmap("media/monster.bmp");
  moneta_t m;
  monster_t mon[NUM_MAX];
  initialize(m, c, mon);
  int score = 0;                        
  int cont = 45; 
  
  bool fine = false;
  
  al_init_font_addon();
  al_init_ttf_addon();
  al_init_image_addon();
  
  ALLEGRO_TIMER *timer = al_create_timer(1.0/FPS);
  ALLEGRO_TIMER *frameTimer = al_create_timer(1.0/frameFPS);
  ALLEGRO_EVENT_QUEUE *event_queue1 = al_create_event_queue();
  ALLEGRO_FONT *font_score = al_load_font("media/horror.ttf", 24, 0);
  
  ALLEGRO_BITMAP *sfondo = al_load_bitmap("media/sfondo_fisso.bmp");
  c.cthulhu_bmp = al_load_bitmap("media/cthulhu3.bmp");
  m.monete = al_load_bitmap("media/moneta.bmp");
  
  ALLEGRO_KEYBOARD_STATE keyState;
  
  al_register_event_source(event_queue1, al_get_timer_event_source(timer));
  al_register_event_source(event_queue1, al_get_timer_event_source(frameTimer));
  al_register_event_source(event_queue1, al_get_keyboard_event_source());
  al_start_timer(timer);
  al_start_timer(frameTimer);

  while(!fine){
    ALLEGRO_EVENT eventi;

    al_wait_for_event(event_queue1, &eventi);
    
    
    if (eventi.type == ALLEGRO_EVENT_TIMER){
      if(eventi.timer.source == timer){
	al_get_keyboard_state (&keyState);
	if (al_key_down(&keyState, ALLEGRO_KEY_DOWN)){
	  if(c.dir_su == true)
	    c.dir_su = false;
	  c.y += c.speed;
	  crea_moneta(m, c, score);
	  if (c.y >= Max){
	    game_over(score);
	    distruggi(fine, event_queue1, timer);
	  }
	}
	
	if (al_key_down(&keyState, ALLEGRO_KEY_UP)){
	  if(c.dir_su == false)
	    c.dir_su = true;
	  c.y -= c.speed;
	  crea_moneta(m, c, score);
	  if (c.y <= Min){
	    game_over(score);
	    distruggi(fine, event_queue1, timer);
	  }
	}
	
	if (al_key_down(&keyState, ALLEGRO_KEY_SPACE)){
	  distruggi(fine, event_queue1, timer);
	}
      }
      else if (eventi.timer.source == frameTimer){
	if(!collisions(cont, mon, c, score))
	  return;
      }
    }
    draw2(m, c, mon, monster, sfondo, font_score, score);
  
  }
  
  al_destroy_bitmap(m.monete);
  al_destroy_bitmap(monster);
}
  
