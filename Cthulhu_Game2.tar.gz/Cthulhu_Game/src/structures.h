/**
 * @file
 * 
 * File header contenente le strutture dati del programma
 */
#include <iostream>

using namespace std;

#define ScreenWidth 700    /**< Larghezza display */
#define ScreenHeight 900   /**< Altezza display */
/**
 * Struttura del player.
 * 
 * Il player potrà muoversi solo su e giù nel display, perciò la sua x rimarrà costante.
 */
struct cthulhu_t{
  bool dir_su;				/**< variabile booleana per il controllo del
					  * posizionamento del player sul display e
					  * del suo spostamento
					  */

  const int x = ScreenWidth/5;		/**< coordinata asse x del player */
  float y;				/**< coordinata asse y del player */
  ALLEGRO_BITMAP *cthulhu_bmp;		/**< bitmap del player */
  const float speed = 12.;		/**< velocità del player */
  const int ch = 48;			/**< altezza del player */
  const int cw = 36;			/**< metà dell'altezza del player, utilizzata
					  * per le collisioni con i mostri
					  */
} ;

/**
 * Struttura della moneta.
 * 
 * Anche la moneta come il player ha la coordinata x costante, in quanto può apparire soltanto lungo la
 * traiettoria del player.
 */
struct moneta_t{
  const int mx = ScreenWidth/5;			/**< coordinata x della moneta */
  float my;					/**< coordinata y della moneta */
  ALLEGRO_BITMAP *monete;
  bool UP;					/**< variabile booleana per il controllo del
						 * posizionamento della moneta, se impostata
						 * a true la moneta si trova nella parte alta
						 * del display, altrimenti in basso
						*/

  const int mh = 30;				/**< altezza della moneta */
};

/**
 * Struttura di un singolo mostro.
 * 
 * I mostri, a differenza della moneta e del player, non hanno una coordinata costante, in quanto possono apparire
 * ad altezze diverse e si muovono da una parte all'altra dello schermo
 */
struct monster_t {
  int x, y;					/**< coordinate x e y del mostro */
  bool active;					/**< variabile booleana utilizzata per
						 * controllare se il mostro è presente sul
						 * display e in caso affermativo disegnarlo
						*/

  const int mh = 22;				/**< altezza del mostro */
  const int larghezza = 24;			/**< larghezza del mostro */
  float speed_monster;				/**< velocità del mostro */
};
